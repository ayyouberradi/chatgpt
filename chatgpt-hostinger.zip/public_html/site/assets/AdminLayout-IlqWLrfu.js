import{c as s,r as h,o as p,p as x,j as e,X as m,q as u,L as l,m as y,O as f}from"./index-5HVDH8gd.js";import{B as v}from"./briefcase-BLFl2vwz.js";import{L as g}from"./layers-Cp1pnAmi.js";import{U as k}from"./users-G_QhmR6a.js";import{B as b}from"./building-2-BSBWxraA.js";import{I as j}from"./image-CUhOFBx4.js";/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const N=s("Award",[["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}],["path",{d:"M15.477 12.89 17 22l-5-3-5 3 1.523-9.11",key:"em7aur"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=s("DollarSign",[["line",{x1:"12",x2:"12",y1:"2",y2:"22",key:"7eqyqh"}],["path",{d:"M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6",key:"1b0p4s"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const z=s("FileText",[["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z",key:"1rqfz7"}],["path",{d:"M14 2v4a2 2 0 0 0 2 2h4",key:"tnqrlb"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=s("LayoutDashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=s("LogOut",[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=s("Scroll",[["path",{d:"M8 21h12a2 2 0 0 0 2-2v-2H10v2a2 2 0 1 1-4 0V5a2 2 0 1 0-4 0v3h4",key:"13a6an"}],["path",{d:"M19 17V5a2 2 0 0 0-2-2H4",key:"zz82l3"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=s("Settings",[["path",{d:"M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",key:"1qme2f"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]);/**
 * @license lucide-react v0.344.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const L=s("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]]),d=[{name:"Dashboard",icon:S,path:"/admin"},{name:"Projects",icon:v,path:"/admin/projects"},{name:"Case Studies",icon:z,path:"/admin/case-studies"},{name:"Services",icon:g,path:"/admin/services"},{name:"Testimonials",icon:k,path:"/admin/testimonials"},{name:"Retainers",icon:M,path:"/admin/retainers"},{name:"Packages",icon:w,path:"/admin/packages"},{name:"Skills",icon:N,path:"/admin/skills"},{name:"Clients",icon:b,path:"/admin/clients"},{name:"About",icon:L,path:"/admin/about"},{name:"Media",icon:j,path:"/admin/media"},{name:"SEO & Settings",icon:C,path:"/admin/settings"}];function V(){const[r,n]=h.useState(!1),o=p(),{signOut:i}=x();return e.jsxs("div",{className:"flex min-h-screen",style:{backgroundColor:"var(--background)",color:"var(--foreground)"},children:[e.jsxs("div",{className:"lg:hidden fixed top-0 left-0 right-0 z-40 p-4 flex items-center justify-between",style:{backgroundColor:"var(--surface-elevated)",borderBottom:"1px solid var(--border)"},children:[e.jsx("span",{className:"font-bold text-lg",children:"Admin Dashboard"}),e.jsx("button",{onClick:()=>n(!r),children:r?e.jsx(m,{size:24}):e.jsx(u,{size:24})})]}),e.jsxs("aside",{className:"w-72 h-screen hidden lg:flex lg:flex-col sticky top-0",style:{backgroundColor:"var(--surface-elevated)",borderRight:"1px solid var(--border)"},children:[e.jsx("div",{className:"p-6 pb-4 shrink-0",children:e.jsx(l,{to:"/",className:"text-xl font-bold",style:{color:"var(--foreground)"},children:"← Back to Site"})}),e.jsx("div",{className:"flex-1 overflow-y-auto p-6 pt-0 no-scrollbar pb-24",children:e.jsx("nav",{className:"space-y-2",children:d.map(a=>{const t=o.pathname===a.path;return e.jsxs(l,{to:a.path,className:"flex items-center gap-3 px-4 py-3 rounded-xl transition-all",style:{backgroundColor:t?"var(--accent)":"transparent",color:t?"var(--accent-foreground)":"var(--foreground)"},children:[e.jsx(a.icon,{size:20}),e.jsx("span",{children:a.name})]},a.path)})})}),e.jsx("div",{className:"mt-auto p-6 pt-4 border-t shrink-0",style:{borderColor:"var(--border)"},children:e.jsxs("button",{onClick:i,className:"flex items-center gap-3 px-4 py-3 rounded-xl transition-all w-full text-left",style:{color:"var(--foreground)"},children:[e.jsx(c,{size:20}),e.jsx("span",{children:"Sign Out"})]})})]}),e.jsxs(y.aside,{initial:!1,animate:{x:r?0:-300},className:"fixed lg:hidden z-50 w-72 h-screen flex flex-col overflow-hidden",style:{backgroundColor:"var(--surface-elevated)",borderRight:"1px solid var(--border)"},children:[e.jsx("div",{className:"p-6 pb-4 shrink-0",children:e.jsx(l,{to:"/",className:"text-xl font-bold",style:{color:"var(--foreground)"},children:"← Back to Site"})}),e.jsx("div",{className:"flex-1 overflow-y-auto p-6 pt-0 no-scrollbar pb-24",children:e.jsx("nav",{className:"space-y-2",children:d.map(a=>{const t=o.pathname===a.path;return e.jsxs(l,{to:a.path,onClick:()=>n(!1),className:"flex items-center gap-3 px-4 py-3 rounded-xl transition-all",style:{backgroundColor:t?"var(--accent)":"transparent",color:t?"var(--accent-foreground)":"var(--foreground)"},children:[e.jsx(a.icon,{size:20}),e.jsx("span",{children:a.name})]},a.path)})})}),e.jsx("div",{className:"mt-auto p-6 pt-4 border-t shrink-0",style:{borderColor:"var(--border)"},children:e.jsxs("button",{onClick:()=>{i(),n(!1)},className:"flex items-center gap-3 px-4 py-3 rounded-xl transition-all w-full text-left",style:{color:"var(--foreground)"},children:[e.jsx(c,{size:20}),e.jsx("span",{children:"Sign Out"})]})})]}),r&&e.jsx("div",{className:"lg:hidden fixed inset-0 bg-black/50 z-40",onClick:()=>n(!1)}),e.jsx("main",{className:"flex-1 p-6 lg:p-10 pt-20 lg:pt-10 overflow-auto",children:e.jsx(f,{})})]})}export{V as default};
